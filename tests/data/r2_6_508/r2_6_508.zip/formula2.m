%Enter your formula here; Input/Output variables are M, Q, Rexp, Err, Pol, An, UserData
%PARAM, dQ and Rth are only inputs. Use printout(x) function to output on the screen your variable x
 
