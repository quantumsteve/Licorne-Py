N=100;
for k=1:N
M.Layers(k).msld(2)=180*(k-1)/(N-1);
end
